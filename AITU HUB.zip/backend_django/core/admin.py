﻿from django.contrib import admin
from .models import LostFoundItem, Product, News


@admin.register(LostFoundItem)
class LostFoundAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'location', 'created_at', 'created_by')
    list_filter = ('status', 'created_at')
    search_fields = ('title', 'description', 'location', 'contact_info')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'price', 'created_at', 'created_by')
    list_filter = ('category', 'created_at')
    search_fields = ('title', 'description', 'contact_info')


@admin.register(News)
class NewsAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'created_by')
    list_filter = ('created_at',)
    search_fields = ('title', 'preview_text', 'content')