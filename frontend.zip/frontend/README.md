﻿# Frontend Placeholder

This repository focuses on Django + FastAPI services.

Use FastAPI interactive docs at:
- http://localhost:8001/docs

Django web UI is available at:
- http://localhost:8000/