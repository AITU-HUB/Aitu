﻿from django import forms
from .models import LostFoundItem, Product, News


class LostFoundForm(forms.ModelForm):
    class Meta:
        model = LostFoundItem
        fields = ['title', 'description', 'status', 'location', 'image_url', 'contact_info']


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['title', 'description', 'price', 'category', 'image_url', 'contact_info']


class NewsForm(forms.ModelForm):
    class Meta:
        model = News
        fields = ['title', 'preview_text', 'content', 'image_url']